#!/bin/sh
cd /usr/lib/clonekeen
exec ./keen "$@"
